"use client"
import { uuid } from "@zuzjs/core";
import { forwardRef, ReactNode, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { animationTransition } from "../../funs/css";
import { useBase } from "../../hooks";
import { ValueOf, ZuzProps } from "../../types";
import { SHEET, SHEET_ACTION_POSITION, TRANSITION_CURVES, TRANSITIONS } from "../../types/enums";
import { animationProps, BoxProps } from "../../types/interfaces";
import Box from "../Box";
import Button from "../Button";
import Cover from "../Cover";
import Overlay from "../Overlay";
import { SPINNER } from "../Spinner/types";

export type SheetProps = ZuzProps & {
    title?: string,
    message?: string | ReactNode,
    transition?: ValueOf<typeof TRANSITIONS>,
    curve?: ValueOf<typeof TRANSITION_CURVES>,
    speed?: number,
    type?: ValueOf<typeof SHEET>,
    spinner?: ValueOf<typeof SPINNER>,
    loadingMessage?: string,
    actionPosition?: ValueOf<typeof SHEET_ACTION_POSITION>,
    onShow?: () => void,
    onHide?: () => void,
}

export interface SheetActionHandler {
    key?: string,
    label: string, 
    handler?: () => void,
    onClick?: () => void,
}

export interface SheetHandler {
    setLoading: ( mode: boolean ) => void,
    showDialog: ( 
        title : string | ReactNode, 
        message : string | ReactNode, 
        action? : SheetActionHandler[], 
        onShow?: () => void 
    ) => void,
    dialog: ( 
        title : string | ReactNode, 
        message : string | ReactNode, 
        action? : SheetActionHandler[], 
        onShow?: () => void 
    ) => void,
    show: ( message : string | ReactNode, duration?: number, type?: ValueOf<typeof SHEET> ) => void,
    success: ( message : string | ReactNode, duration?: number ) => void,
    error: ( message : string | ReactNode, duration?: number ) => void,
    warn: ( message : string | ReactNode, duration?: number ) => void,
    hide: () => void,
}

let _sheetTimeout: ReturnType<typeof setTimeout> | null = null
let _sheetWobbleTimeout: ReturnType<typeof setTimeout> | null = null

/**
 * Sheet component.
 *
 * @example
 * // Basic usage
 * ```tsx
 * <Sheet isOpen={true} onClose={() => setOpen(false)}>Content here</Sheet>
 * ```
 *
 * @example
 * // Advanced usage with additional props
 * ```tsx
 * <Sheet isOpen={true} onClose={() => setOpen(false)} position="bottom" size="md" backdrop>Bottom sheet</Sheet>
 * ```
 * @param isOpen - Whether sheet is open
 * @param onClose - Callback function triggered when closing
 * @param position - position prop
 * @param size - Component size
 * @param backdrop - backdrop prop
 */
const Sheet = forwardRef<SheetHandler, SheetProps>((props, ref) => {

    const { 
        title : _title, 
        message, transition, 
        curve, speed, type, actionPosition, spinner, 
        loadingMessage, 
        onShow, onHide,
        ...pops } = props

    const {
        className,
        style,
        rest
    } = useBase(pops as BoxProps)

    const [ title, setTitle ] = useState<string | ReactNode>(_title || ``)
    const [ msg, setMsg ] = useState<string | ReactNode>(message || ``)
    const [ action, setAction ] = useState<SheetActionHandler[] | null>(null)
    const [ sheetType, setSheetType ] = useState<ValueOf<typeof SHEET>>(type || SHEET.Default);
    const sheetID = useMemo(() => uuid(12), [])
    const [ visible, setVisible ] = useState(false)
    const innerRef = useRef<HTMLDivElement>(null);
    const lastTransform = useRef<string | null>(null)
    const [ loading, setLoading ] = useState(false)
    const [ render, setRender ] = useState(true)
    const _render = useRef<ReturnType<typeof setTimeout> | null>(null)

    const renderMessage = msg //useMemo(() => msg, [msg])

    useImperativeHandle(ref, () => ({
        setLoading(mode: boolean){
            setLoading(mode)
        },
        showDialog( 
            title?: string | ReactNode | null, 
            message?: string | ReactNode | null, 
            action?: SheetActionHandler[],
            onShow?: () => void ){

            if ( _sheetTimeout ){
                clearTimeout(_sheetTimeout);
                if ( _sheetWobbleTimeout ){
                    clearTimeout(_sheetWobbleTimeout);
                }
                innerRef.current!.classList.remove(`--wobble`)
                setTimeout(() => innerRef.current!.classList.add(`--wobble`), 50)
                _sheetWobbleTimeout = setTimeout(() => {
                    innerRef.current!.classList.remove(`--wobble`)
                    _sheetWobbleTimeout = null
                }, 500)
            }

            setSheetType(SHEET.Dialog)
            if ( message ) setMsg(message);
            if ( title ) setTitle(title);
            if ( action ) setAction(action.reduce((ar, b) => {
                ar.push({
                    ...b,
                    key: b.key || uuid(12)
                })
                return ar
            }, [] as SheetActionHandler[]));
            setVisible(true);

            setTimeout(() => onShow ? onShow() : () => {}, 1000)
        },
        dialog( 
            title: string | ReactNode, 
            message: string | ReactNode, 
            action?: SheetActionHandler[],
            // actionRef?: React.RefObject<HTMLElement>,
            onShow?: () => void ){

            if ( _sheetTimeout ){
                clearTimeout(_sheetTimeout);
                if ( _sheetWobbleTimeout ){
                    clearTimeout(_sheetWobbleTimeout);
                }
                innerRef.current!.classList.remove(`--wobble`)
                setTimeout(() => innerRef.current!.classList.add(`--wobble`), 50)
                _sheetWobbleTimeout = setTimeout(() => {
                    innerRef.current!.classList.remove(`--wobble`)
                    _sheetWobbleTimeout = null
                }, 500)
            }

            setSheetType(SHEET.Dialog)
            setMsg(message);
            setTitle(title);
            if ( action ) setAction(action.reduce((ar, b) => {
                ar.push({
                    ...b,
                    key: b.key || uuid(12)
                })
                return ar
            }, [] as SheetActionHandler[]));
            setVisible(true);

            setTimeout(() => onShow ? onShow() : () => {}, 1000)
        },
        error( message: string | ReactNode, duration?: number){
            this.show( message, duration, SHEET.Error)  
        },
        warn( message: string | ReactNode, duration?: number){
            this.show( message, duration, SHEET.Warn)  
        },
        success( message: string | ReactNode, duration?: number){
            this.show( message, duration, SHEET.Success)  
        },
        show( message: string | ReactNode, duration?: number, type?: ValueOf<typeof SHEET> ){
            
            if ( _sheetTimeout ){
                clearTimeout(_sheetTimeout);
                if ( _sheetWobbleTimeout ){
                    clearTimeout(_sheetWobbleTimeout);
                }
                // if ( lastTransform ) innerRef.current!.style.transform = _lastTransform
                lastTransform.current = innerRef.current!.style.transform
                innerRef.current!.style.transform = ``
                innerRef.current!.classList.remove(`--wobble`)
                setTimeout(() => {
                    innerRef.current!.classList.add(`--wobble`)
                    innerRef.current!.style.transform = `${lastTransform.current} scale(.9)`.trim()
                }, 50)
                _sheetWobbleTimeout = setTimeout(() => {
                    innerRef.current!.classList.remove(`--wobble`)
                    innerRef.current!.style.transform = lastTransform.current || ``
                    _sheetWobbleTimeout = null
                }, 500)
            }              
            
            _sheetTimeout = setTimeout(() => {
                setVisible(false)
                _sheetTimeout = null
                _sheetWobbleTimeout = null
            }, (duration || 4) * 1000)
            
            setSheetType(type || SHEET.Default)
            setMsg(message);
            setVisible(true);

            onShow?.()

        },
        hide(){
            setVisible(false)
            onHide?.()
        }
    }))

    const buildAnimation = useMemo(() => {

        const base = {
            when: visible,
            duration: speed || 0.3,
            delay: 0.1,
        }

        if ( sheetType == SHEET.Dialog){

            if ( transition ){

                const { from, to } = animationTransition(transition, 20)

                return{
                    // from: { ...from, x: `-50%`, y: `-50%` },
                    // to: { ...to, x: `-50%`, y: `-50%` },
                    // from: { ...from, x: `-50%` },
                    // to: { ...to, x: `-50%` },
                    from, to,
                    curve: curve || TRANSITION_CURVES.EaseInOut,
                    ...base
                }    
            }

            return{
                from: { scale: 0, x: `-50%`, y: `-50%`, opacity: 0 },
                to: { scale: 1, x: `-50%`, y: `-50%`, opacity: 1 },
                curve: TRANSITION_CURVES.Spring,
                ...base
            }
            
        }
        else {
            return {
                from: { scale: 0, x: `-50%`, y: `-10vh`, opacity: 0 },
                to: { scale: 1, x: `-50%`, y: 0, opacity: 1 },
                curve: TRANSITION_CURVES.Spring,
                ...base
            }
        }
    }, [visible, sheetType])

    useEffect(() => {
        if ( _render.current ) clearTimeout(_render.current)
        if ( !visible ){
            _render.current = setTimeout(() => setRender(false), 1000)
        }
        else{
            setRender(true)
        }
    }, [visible])

    if ( sheetType == SHEET.Dialog ){
        return <>

            <Overlay when={visible} />

            <Box
                className={`--sheet --sheet-${sheetType.toLowerCase()} ${visible ? `is-visible` : ``} ${className} fixed`.trim()}
                style={style}
                fx={buildAnimation as animationProps}
                {...rest as BoxProps}
                ref={innerRef}>

                <Cover when={loading} spinner={spinner} message={loadingMessage} />
                
                {/* Header */}
                <Box className={`--head flex aic rel`}>
                    <Box className={`--${title ? `title` : `dot`} flex aic rel`}>{title || ``}</Box>
                    <Button 
                        onClick={(e) => setVisible(false)}
                        className={`--closer abs`}>&times;</Button>
                </Box>
                {/* Body */}
                <Box className={`--body flex aic rel ${action ? `` : `--no-action`}`.trim()}>
                    {render ? renderMessage : null}
                </Box>
                {/* Footer */}
                { action && <Box className={`--footer flex aic rel ${actionPosition ? actionPosition == SHEET_ACTION_POSITION.Center ? `jcc` : `` : `jce`}`.trim()}>
                    {action.map((a: SheetActionHandler, i: number) => <Button 
                        key={`sheet-${sheetID}-action-${a.key}`}  
                        onClick={(e) => a.handler ? a.handler() : a.onClick ? a.onClick() : console.log(`onClick Handler missing`)}
                        className={`--action`}>{a.label}</Button>)}
                </Box> }

            </Box>

        </>
    } 

    return <Box
        className={`--sheet --sheet-${sheetType.toLowerCase()} ${className} abs`.trim()}
        style={style}
        {...rest as BoxProps}
        fx={buildAnimation as animationProps}
        ref={innerRef}>
        {visible ? msg : null}
    </Box>
})

export const isSheetHandler = (src: unknown): src is SheetHandler => {
    return typeof src === `object` 
        && null != src 
        && `setLoading` in src
        && `success` in src
        && `error` in src
}


Sheet.displayName = `Zuz.Sheet`

export default Sheet