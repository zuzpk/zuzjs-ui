"use client"
import { forwardRef, useEffect, useMemo, useState } from 'react';
import { useBase } from '../../hooks';
import { useTheme } from '../../hooks/useColorScheme';
import { Variant } from '../../types';
import Box from '../Box';
import Button from '../Button';
import Input from '../Input';
import SVGIcons from '../svgicons';
import Text from '../Text';
import { InputProps } from '../Input/types';
import { checkPasswordStrength } from '@zuzjs/core';
import { useDebounce } from '@zuzjs/hooks';

export type PasswordProps = Omit<InputProps, `type` | `numeric`> & {
    strenthMeter?: boolean
}

/**
 * Password component.
 *
 * @example
 * // Basic usage
 * ```tsx
 * <Password onChange={(pass) => console.log(pass)} />
 * ```
 *
 * @example
 * // Advanced usage with additional props
 * ```tsx
 * <Password onChange={(pass) => console.log(pass)} strength={true} showStrength variant="primary" />
 * ```
 * @param onChange - Callback function triggered when value changes
 * @param strength - strength prop
 * @param showStrength - showStrength prop
 * @param variant - Visual variant or style
 */
const Password = forwardRef<HTMLInputElement, PasswordProps>((props, ref) => {

    const { strenthMeter, onChange, ...pops } = props
    const { variant: themeVariant } = useTheme(true)!

    if ( `type` in pops ){
        delete pops[`type`]
    }

    const {
        style,
        className,
        rest
    } = useBase(pops)

    const [ visible, setVisible ] = useState(false)
    const [ passw, setPassw ] = useState("")

    const strenth = useMemo(() => checkPasswordStrength(passw), [passw])
 
    const debounce = useDebounce((ev) => {
        if ( strenthMeter ) setPassw(ev.target.value)
        onChange && onChange(ev)
    }, 100)

    useEffect(() => {}, [])

    return <Box as={`w:100% flex cols`}>
        <Box 
            style={style}
            className={`--password --${props.variant || themeVariant || Variant.Medium} flex aic rel`}>
            <Input 
                ref={ref}
                type={visible ? 'text' : 'password'}
                className={className}
                onChange={debounce}
                {...rest as InputProps} />
            <Button 
                tabIndex={-1}
                onClick={() => setVisible(prev => !prev)}
                className={`--toggle flex aic jcc abs`}>
                {visible ? SVGIcons.eye : SVGIcons.eyeSlash}
            </Button>
        </Box>
        {strenthMeter && <Box as={`flex aic --password-meter --pb-score-${strenth.score}`} style={style}>
            <Box as={`--password-bars flex aic`}>
                <Box as={`--pbar ${strenth.score >= 1 ? `--pb-on` : ``}`.trim()} />                                            
                <Box as={`--pbar ${strenth.score >= 2 ? `--pb-on` : ``}`.trim()} />                                            
                <Box as={`--pbar ${strenth.score >= 3 ? `--pb-on` : ``}`.trim()} />                                            
                <Box as={`--pbar ${strenth.score >= 4 ? `--pb-on` : ``}`.trim()} />                                            
                <Box as={`--pbar ${strenth.score >= 5 ? `--pb-on` : ``}`.trim()} />                                            
            </Box>
            <Text as={`--password-meter-label`} aria-hidden={true}>{strenth.result}</Text>
        </Box>}
    </Box>
})

Password.displayName = `Zuz.Password`

export default Password